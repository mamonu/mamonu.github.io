import pytest
from calcs.calcs import add,subtract
from hypothesis import given,assume,settings,strategies as st

# @given(st.floats(allow_nan=False,allow_infinity=False),st.floats(allow_nan=False,allow_infinity=False))
# def test_addHyp(a,b):
#     assert add(a,b) == a + b  

# @given(st.floats(allow_nan=False,allow_infinity=False),st.floats(allow_nan=False,allow_infinity=False))
# def test_subtractHyp(a,b):
#     assert subtract(a,b) == a - b 

