import pytest
from calcs.calcs import add,subtract

inp1=0.1
inp2=0.2

def test_add():
    
    answer=inp1 + inp2
    result = add(inp1,inp2)  

    assert answer == result

def test_subtract():
  
    
    answer =inp1 - inp2
    result = subtract(inp1,inp2)  

    assert answer == result
