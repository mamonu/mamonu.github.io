import pytest



def add(a,b):
    c = a + b
    print(c)
    return c

def subtract(a,b):
    c = a - b
    print(c)
    return c